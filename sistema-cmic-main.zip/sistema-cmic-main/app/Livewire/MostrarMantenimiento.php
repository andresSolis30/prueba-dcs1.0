<?php

namespace App\Livewire;

use Livewire\Component;

class MostrarMantenimiento extends Component
{ 
    public $mantenimiento;

    public function render()
    {
        return view('livewire.mostrar-mantenimiento');
    }
}
 