<?php

namespace App\Livewire;

use Livewire\Component;

class FirmasAreaEmpleado extends Component
{
    public function render()
    {
        return view('livewire.firmas-area-empleado');
    }
}
