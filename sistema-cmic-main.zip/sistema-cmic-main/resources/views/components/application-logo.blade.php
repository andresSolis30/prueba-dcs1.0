<div class="text-center mb-6">
    <img src="{{ asset('img/LOGO_TABASCO.png') }}" alt="Logo de la Empresa" class="mx-auto h-20 w-auto">
</div>
