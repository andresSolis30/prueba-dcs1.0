<div class="text-red-600 font-bold uppercase p-2 mt-2 text-xs">
    {{$message}}
</div>
